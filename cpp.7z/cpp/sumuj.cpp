/*
 * sumuj.cpp
 * sumuje 10 liczb, wynik drukuje na ekranie.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int i;

    for (i = 1; i < 101; i++)
    {
        
    }

    return 0;
}

