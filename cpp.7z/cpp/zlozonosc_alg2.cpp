/*
 * zlozonosc_alg2.cxx
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int a;
    cout<<"Podaj a: "<<endl;
    cin>>a;
    for (int 0 < a < 100: i < i; i++)
	
	return 0;
}

