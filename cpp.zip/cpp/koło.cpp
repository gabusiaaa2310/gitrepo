/*
 * hello.cpp
 */


#include <iostream>
#include <math.h>

using namespace std;

int main(int argc, char **argv)
{
	int r=0
	
	cout <<"Podaj promień: " <<endl;
	cin >> r;
	cout<<"Pole koła = "<< M_PI*r*r<<endl;
	cout<<"Obwód koła = "<<M_PI*r*2<<endl;
	
	return 0;
}

