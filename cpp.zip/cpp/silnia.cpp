/*
 * silnia.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int a;
    int wynik=1;
    
    cout<<"podaj liczbę naturalną: ";
    cin>>a;
    
    for(int i=1, i<=a, i++)
     
	
	return 0;
}

