/*
 * Szabat_lokata.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	
	return 0;
}

