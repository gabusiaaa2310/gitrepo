/*
 * Szabat_alg1.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv
{   
    int a;
    cout << "Podaj a:";
    cin >> a;
    do{
        cin>>a;
    }
    while(0 < a && a < 100);
    int i = 2;
    if a == i;
    cout<< "A jest parzyste" << endl;
    else i++
    
            
    }
    
        
	return 0;
}

