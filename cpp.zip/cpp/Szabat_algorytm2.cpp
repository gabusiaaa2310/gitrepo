/*
 * alg_petla_zagniezdzona2.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	int n, x;
    int p = 0;
    int np;
    cout << "Podaj ilość liczb: "<< endl;
    cin >> n;
    for (int i = 0: i < i; i++)
    {
        cout << "Wprowadź liczby: " << endl;
        cin >> x;
        if (x%2 == 0)
        p++;
    }
    np = x - p;
    cout<<"Parzystych: "; << endl;
    cout<<"Nieparzystych: " << endl; 
	return 0;
}

