/*
 * hello.cpp
 */


#include <iostream>
using namespace std;

int main(int argc, char **argv)
{

    int liczba 1= liczba 2= liczba 3= liczba 4= liczba 5= liczba 6= liczba 7= liczba 8= liczba 9= liczba 10= 0;
    cout << "Podaj 10 liczb";
    cin >> liczba 1;
    cin >> liczba 2;
    cin >> liczba 3;
    cin >> liczba 4;    
    cin >> liczba 5;    
    cin >> liczba 6;    
    cin >> liczba 7;
    cin >> liczba 8;    
    cin >> liczba 9;
    cin >> liczba 10;        
    cout << "Suma liczb wynosi" << liczba 1 + liczba 2 + liczba 3 + liczba 4 + liczba 5 + liczba 6 + liczba 7 + liczba 8 + liczba 9 + liczba 10<< endl

    
    
	return 0;
}

