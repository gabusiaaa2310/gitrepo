/*
 * alg_interacyjny1.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
	int n, a;
    int iloczyn = 1;
    int i;
    
    cout << "Podaj n: ";
    cin >> n;
    
    cout << "Podaj a: ";
    cin >> a;

    while (i!=n)
    {
        if (i = n)
        cout << "Podaj iloczyn: ";
        cin >> iloczyn;
    else
        i = i + 1
    }
    
    cout << "Wynik: " << iloczyn << endl;
	
    return 0;
}

